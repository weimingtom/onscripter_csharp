start Debug\onscripter.exe
